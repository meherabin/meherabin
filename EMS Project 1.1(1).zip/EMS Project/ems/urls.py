from django.contrib import admin
from django.urls import path
from main import views

urlpatterns = [
    path('', views.home, name='home'),
    path('admin/', views.admin_home, name='admin-home'),
    path('admin/login/', views.admin_login, name='admin-login'),
    path('admin/logout/', views.admin_logout, name='admin-logout'),
    path('admin/add-user/', views.add_user, name='add-user'),
    path('admin/user/<int:id>', views.user, name='user'),
    path('admin/edit-user/<int:id>', views.edit_user, name='edit-user'),
    path('admin/delete-user/<int:id>', views.delete_user, name='delete-user'),
    path('employee/', views.employee_home, name='employee-home'),
    path('employee/login/', views.employee_login, name='employee-login'),
    path('employee/logout/', views.employee_logout, name='employee-logout'),
]
