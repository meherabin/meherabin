from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.models import auth
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from main.models import UserLog
from django.utils import timezone

def home(request):        
    return render(request, 'home.html')

# Admin Login
def admin_login(request):
    if request.method == 'GET':
        return render(request, 'admin_login.html')

    elif request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(username=username, password=password)
                
        if user is not None and (user.is_superuser or user.is_staff):
            login(request, user)
            user_log = UserLog(login_timestamp=timezone.now(), user=request.user)
            user_log.save()
            if request.GET:
                return redirect(request.GET['next'])
            return redirect('admin-home')

        else:
            messages.error(request, 'Invalid Credentials!')
            return render(request, 'admin_login.html')


# Admin Logout
def admin_logout(request):
    user_log = UserLog.objects.filter(user__id=request.user.id).last()
    user_log.logout_timestamp = timezone.now()
    user_log.save()
    
    logout(request)
    return redirect('/')


@user_passes_test(lambda user: user.is_superuser)
def admin_home(request):
    if request.method == 'POST':
        date = request.POST['date']
        userlogs = UserLog.objects.filter(login_timestamp__gte=date)

        context = {
            'userlogs': userlogs,
            'date': date
        }
        return render(request, 'admin_home.html', context)

    elif request.method == 'GET':
        date = timezone.now().date()
        userlogs = UserLog.objects.filter(login_timestamp__gte=date)
        for ul in userlogs:
            print('ul')

        context = {
            'userlogs': userlogs,
            'date': date
        }
        return render(request, 'admin_home.html', context)

# Admin Get User
@user_passes_test(lambda user: user.is_superuser)
def user(request, id):
    user = User.objects.get(id=id)

    if request.user.is_authenticated and request.user.is_superuser:
        context = {
            'req_user': user,
        }
        return render(request, 'user.html', context)
    else:
        return redirect('/')


# Admin Add User
@user_passes_test(lambda user: user.is_superuser)
def add_user(request):
    if request.method == "GET":
        return render(request, 'add_user.html')

    elif request.method == "POST":
        username = request.POST["username"]
        password1 = request.POST["password1"]
        password2 = request.POST["password2"]

        if password1 != password2:
            messages.error(request, 'Passwords are not same!')
            return redirect('add-user')


        elif User.objects.filter(username=username).exists():
            messages.error(request, 'Username already in used!')
            return redirect('add-user')
            
        else:
            user = User.objects.create_user(username=username, password=password1)
            user.save()
            messages.success(request, 'Employee created successfully!')
            return redirect('add-user')


# Admin Edit User
@user_passes_test(lambda user: user.is_superuser)
def edit_user(request, id):
    user = User.objects.get(id=id)
    context = {
        'edit_user' : user
    }
    if request.user.is_authenticated and request.user.is_superuser:
        if request.method == "GET":
            return render(request, "edit_user.html", context)

        elif request.method == "POST":
            username = request.POST["username"]
            password1 = request.POST["password1"]
            password2 = request.POST["password2"]

            if password1 != password2:
                messages.error(request, 'Passwords are not same!')
                return redirect('edit-user')

            elif User.objects.filter(username=username).exists():
                messages.error(request, 'Username already in used!')
                return redirect('add-user')
            else: 
                user.username = username
                user.set_password(password1) 
                user.save()

                messages.success(request, 'Updated Successfully!')
                return redirect(request.META.get('HTTP_REFERER', 'redirect_if_referer_not_found'))

    else:
        return redirect('/')


# Admin Delete User
@user_passes_test(lambda user: user.is_superuser)
def delete_user(request, id):
    user = User.objects.get(id=id)

    if request.user.is_authenticated and request.user.is_superuser:
        user.delete()
        return redirect("admin-home")
    else:
        return redirect('/')



# Employee Login
def employee_login(request):
    if request.method == 'GET':
        return render(request, 'employee_login.html')

    elif request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(username=username, password=password)
                
        if user is not None:
            login(request, user)
            # print(timezone.now())
            user_log = UserLog(login_timestamp=timezone.now(), user=request.user)
            user_log.save()
            if request.GET:
                return redirect(request.GET['next'])
            return redirect('employee-home')

        else:
            messages.error(request, 'Invalid Credentials!')
            return render(request, 'employee_login.html')


# Employee Logout
def employee_logout(request):
    user_log = UserLog.objects.filter(user__id=request.user.id).last()
    user_log.logout_timestamp = timezone.now()
    user_log.save()

    logout(request)

    return redirect('/')


@login_required(login_url='/employee/login/')
def employee_home(request):
    return render(request, 'employee_home.html')