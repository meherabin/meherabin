from django.contrib.auth.models import User
from django.db import models

class UserLog(models.Model):
    login_timestamp = models.DateTimeField(blank=True, null=True)
    logout_timestamp = models.DateTimeField(blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)